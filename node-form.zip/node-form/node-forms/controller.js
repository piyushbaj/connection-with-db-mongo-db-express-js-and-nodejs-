const EmployeeModel = require('./schema')

let controller = {}

controller.add= function(req,res){
  let employee = new EmployeeModel({
    f_name : req.body.f_name, l_name : req.body.l_name
  })
  employee.save(function(err,data)
  {
    if(err)  {
      console.log(err)
      return err
    }
  //  return res.json(data)
  res.redirect('/')
  })
}
controller.get= function(req, res){
EmployeeModel.find(function(err,data)
{
  if(err)  {
    console.log(err)
    return err
  }
    res.render('index',{
      data:data
    })
})

}

module.exports= controller;
