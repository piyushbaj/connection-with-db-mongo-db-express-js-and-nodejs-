const mongoose = require('mongoose')

const schema= mongoose.Schema;

let emp = new schema({
  f_name : String,
  l_name : String
})

let model= mongoose.model('emptable',emp)
module.exports=model
